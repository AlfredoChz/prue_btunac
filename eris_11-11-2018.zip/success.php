<section id="content">
    <div class="container content">  
		<div class="alert alert-success alert-dismissible clearfix">
			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<div class="mg-alert-icon"><i class="fa fa-check"></i></div>
			<h3 class="mg-alert-payment"><?php check_message()?></h3>
		</div>
	</div>
</section>